function show() {
	alert("환영합니다. 음악 창은 밑에 있습니다.")
}